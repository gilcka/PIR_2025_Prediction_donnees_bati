import copy
import random as rd
import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer, KNNImputer


shp_file = "couches/bat_resi_complet_sxy.shp"
BD_complet = gpd.read_file(shp_file)

# Copie des données utiles de la couche
lst_id = list(BD_complet["ID"])
lst_data = np.array(BD_complet[["x", "y", "HAUTEUR"]])

# Préparation des jeux de données
N = len(lst_data) # nombre total de bâtiments
id_test, lst_train, lst_test = [],  [], []
for i in range(N):
    nb = rd.random()
    if nb > 0.8: # 20% de proba d'être dans le jeu de test
        id_test.append(lst_id[i])
        lst_test.append( list(lst_data[i]) )
        lst_test[-1][-1] = np.nan # suppression du paramètre HAUTEUR à prédire
    else: # 80% de proba d'être dans le jeu d'entraînement
        lst_train.append( list(lst_data[i]) )
N_test = len(lst_test)
lst_local = copy.deepcopy(lst_train) # jeu à imputer 
"""
# Moyenne

## Prédiction
sum_MSE, sum_MAE = 0, 0
lst_local.append(lst_test[0]) # moyenne => même prédiction pour toutes les hauteurs manquantes
imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
lst_out = imputer.fit_transform(lst_local)
val_pred = np.round(lst_out[-1][-1], 1)
for j in range(N_test):
    bat_index = lst_id.index(id_test[j])
    val_reel = lst_data[bat_index][2]
    # print(id_test[j], '| Préd :', np.round(lst_out[-1][-1], 1), '| Réel :', val_reel)
    sum_MSE += (val_pred - val_reel) ** 2
    sum_MAE += np.abs(val_pred - val_reel)
    lst_local.pop()

## Erreurs
RMSE = np.sqrt(sum_MSE / N_test)
MAE = sum_MAE / N_test
print("Moyenne")
print("RMSE :", RMSE)
print("MAE :", MAE, "m")
print("")
"""
    
# KNN
        
## Prédiction (test avec 1 à 10 voisins)
for a in range(1, 11):

    lst_pred, lst_reel = [],  []
    sum_MSE, sum_MAE = 0, 0
    for j in range(N_test):
        lst_local.append(lst_test[j])
        imputer = KNNImputer(n_neighbors=a, weights="uniform")
        lst_out = imputer.fit_transform(lst_local)
        val_pred = np.round(lst_out[-1][-1], 1)
        lst_pred.append(val_pred)
        bat_index = lst_id.index(id_test[j])
        val_reel = lst_data[bat_index][2]
        lst_reel.append(val_reel)
        # print(id_test[j], '| Préd :', np.round(lst_out[-1][-1], 1), '| Réel :', val_reel)
        lst_local.pop()
        sum_MSE += (val_pred - val_reel) ** 2
        sum_MAE += np.abs(val_pred - val_reel)
    
    ## Erreurs
    RMSE = np.sqrt(sum_MSE / N_test)
    MAE = sum_MAE / N_test
    
    sum_R2_n, sum_R2_d = 0, 0
    h_moy = np.mean( np.array(lst_reel) )
    for i in range(N_test):
        sum_R2_n += (lst_reel[i] - lst_pred[i]) ** 2
        sum_R2_d += (lst_reel[i] - h_moy) ** 2
    R2 = 1 - ( sum_R2_n / sum_R2_d )
    
    print(str(a) + "-NN")
    print("RMSE :", RMSE)
    print("MAE :", MAE, "m")
    print("R2 :", R2)
    print("")
    
    plt.figure()
    plt.hist(lst_pred)
    plt.title(f"Hauteur prédite des bâtiments ({str(a)}-NN)")
    plt.xlabel("Hauteur (m)")
    plt.ylabel("Fréquence")
    
    plt.figure()
    plt.hist(lst_reel, color='g')
    plt.title(f"Hauteur réelle des bâtiments ({str(a)}-NN)")
    plt.xlabel("Hauteur (m)")
    plt.ylabel("Fréquence")