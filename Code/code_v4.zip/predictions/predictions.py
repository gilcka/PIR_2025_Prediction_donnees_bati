import copy
import random as rd
import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.metrics import r2_score


shp_file = "couches/bat_resi_complet_sxy_paris_est.shp"
BD_complet = gpd.read_file(shp_file)

# Copie des données utiles de la couche
lst_id = list(BD_complet["ID"])
lst_data = np.array(BD_complet[["x", "y", "s", "HAUTEUR"]])

# Préparation des jeux de données
N = len(lst_data) # nombre total de bâtiments
id_test, lst_train, lst_test = [],  [], []
for i in range(N):
    nb = rd.random()
    if nb > 0.8: # 20% de proba d'être dans le jeu de test
        id_test.append(lst_id[i])
        lst_test.append( list(lst_data[i]) )
        lst_test[-1][-1] = np.nan # suppression du paramètre HAUTEUR à prédire
    else: # 80% de proba d'être dans le jeu d'entraînement
        lst_train.append( list(lst_data[i]) )
N_test = len(lst_test)
lst_local = copy.deepcopy(lst_train) # jeu à imputer 
      
"""
# Moyenne

## Prédiction
lst_pred, lst_reel = [],  []
sum_MSE, sum_MAE = 0, 0
lst_local.append(lst_test[0]) # moyenne => même prédiction pour toutes les hauteurs manquantes
imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
lst_out = imputer.fit_transform(lst_local)
val_pred = np.round(lst_out[-1][-1], 1)
for j in range(N_test):
    bat_index = lst_id.index(id_test[j])
    val_reel = lst_data[bat_index][-1]
    lst_reel.append(val_reel)
    lst_pred.append(val_pred)
    # print(id_test[j], '| Préd :', np.round(lst_out[-1][-1], 1), '| Réel :', val_reel)
    sum_MSE += (val_pred - val_reel) ** 2
    sum_MAE += np.abs(val_pred - val_reel)
    lst_local.pop()

## Erreurs
RMSE = np.sqrt(sum_MSE / N_test)
MAE = sum_MAE / N_test
R2 = r2_score(lst_reel, lst_pred)
print("Moyenne")
print("RMSE :", RMSE)
print("MAE :", MAE, "m")
print("R2 :", R2)
print("")
"""
    
# KNN
        
def custom_distance(x, y, missing_values = np.nan):
    x1, y1, s1 = x[0], x[1], x[2]
    x2, y2, s2 = y[0], y[1], y[2]
    return np.sqrt( lambda_val * ((x1-x2)**2 + (y1-y2)**2) + (1-lambda_val) * (s1-s2)**2 )


## Prédiction (test avec 1 à 10 voisins)
for k in range(1, 11):
    lambda_values = [val/100 for val in range(0, 33, 5)]
    for lambda_val in lambda_values :
        lst_pred, lst_reel = [],  []
        sum_MSE= 0
        sum_MAE_1, sum_MAE_2, sum_MAE_3 = 0, 0, 0
        N_test_1, N_test_2, N_test_3 = 0, 0, 0
        for j in range(N_test):
            lst_local.append(lst_test[j])
            imputer = KNNImputer(n_neighbors=k, weights="uniform", metric=custom_distance)
            lst_out = imputer.fit_transform(lst_local)
            val_pred = np.round(lst_out[-1][-1], 1)
            lst_pred.append(val_pred)
            bat_index = lst_id.index(id_test[j])
            val_reel = lst_data[bat_index][-1]
            lst_reel.append(val_reel)
            # print(id_test[j], '| Préd :', np.round(lst_out[-1][-1], 1), '| Réel :', val_reel)
            lst_local.pop()
            sum_MSE += (val_pred - val_reel) ** 2
            if val_reel < 10:
                sum_MAE_1 += np.abs(val_pred - val_reel)
                N_test_1 += 1
            elif val_reel >= 10 and val_reel < 30:
                sum_MAE_2 += np.abs(val_pred - val_reel)
                N_test_2 += 1
            else:
                sum_MAE_3 += np.abs(val_pred - val_reel)
                N_test_3 += 1
        
        ## Erreurs
        print(str(k) + "-NN" + "\t\tLambda : " + str(lambda_val))
        RMSE = np.sqrt(sum_MSE / N_test)
        print(f"RMSE :\t\t\t{RMSE:.2f}")
        if N_test_1 != 0 :
            MAE_1 = sum_MAE_1 / N_test_1
            print(f"MAE (-10 m) :\t{MAE_1:.2f} m")
        if N_test_2 != 0 :
            MAE_2 = sum_MAE_2 / N_test_2
            print(f"MAE (10-30 m) :\t{MAE_2:.2f} m")
        if N_test_3 != 0 :
            MAE_3 = sum_MAE_3 / N_test_3
            print(f"MAE (+30 m) :\t{MAE_3:.2f} m")
        R2 = r2_score(lst_reel, lst_pred)
        print(f"R2 :\t\t\t\t{R2:.2f}")
        print("")
        
        plt.figure()
        plt.hist(lst_pred, bins=100)
        plt.title(f"Hauteur prédite des bâtiments | {str(k)}-NN | lambd = {str(lambda_val)}")
        plt.xlabel("Hauteur (m)")
        plt.ylabel("Fréquence")
        
        plt.figure()
        plt.hist(lst_reel, color='g', bins=100)
        plt.title(f"Hauteur réelle des bâtiments | {str(k)}-NN | lambd = {str(lambda_val)}")
        plt.xlabel("Hauteur (m)")
        plt.ylabel("Fréquence")