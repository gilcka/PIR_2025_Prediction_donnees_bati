import copy
import random as rd
import numpy as np
import geopandas as gpd
from sklearn.impute import SimpleImputer, KNNImputer


shp_file = "couches/bat_resi_complet_centroides.shp"
BD_complet = gpd.read_file(shp_file)

# Copie des données utiles de la couche
lst_id = list(BD_complet["ID"])
lst_data = np.array(BD_complet[["x", "y", "HAUTEUR"]])

# Préparation des jeux de données
N = len(lst_data) # nombre total de bâtiments
id_test, lst_train, lst_test = [],  [], []
for i in range(N):
    nb = rd.random()
    if nb > 0.8: # 20% de proba d'être dans le jeu de test
        id_test.append(lst_id[i])
        lst_test.append( list(lst_data[i]) )
        lst_test[-1][-1] = np.nan # suppression du paramètre HAUTEUR à prédire
    else: # 80% de proba d'être dans le jeu d'entraînement
        lst_train.append( list(lst_data[i]) )
    
# Moyenne

## Prédiction
N_test = len(lst_test)
lst_local = copy.deepcopy(lst_train) # jeu à imputer
for j in range(N_test):
    lst_local.append(lst_test[j])
    imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
    lst_out = imputer.fit_transform(lst_local)
    val_pred = np.round(lst_out[-1][-1], 1)
    bat_index = lst_id.index(id_test[j])
    val_reel = lst_data[bat_index][2]
    # print(id_test[j], '| Préd :', np.round(lst_out[-1][-1], 1), '| Réel :', val_reel)
    lst_local.pop()

## Erreurs
sum_MSE, sum_MAE = 0, 0
for k in range(N_test):
    sum_MSE += (val_pred - val_reel) ** 2
    sum_MAE += np.abs(val_pred - val_reel)
RMSE = np.sqrt(sum_MSE / N_test)
MAE = sum_MAE / N_test
print("Moyenne")
print("RMSE :", RMSE, "m")
print("MAE :", MAE, "m")
print("")

    
# KNN
        
## Prédiction
N_test = len(lst_test)
lst_local = copy.deepcopy(lst_train) # jeu à imputer
for j in range(N_test):
    lst_local.append(lst_test[j])
    imputer = KNNImputer(n_neighbors=2, weights="uniform")
    lst_out = imputer.fit_transform(lst_local)
    val_pred = np.round(lst_out[-1][-1], 1)
    bat_index = lst_id.index(id_test[j])
    val_reel = lst_data[bat_index][2]
    # print(id_test[j], '| Préd :', np.round(lst_out[-1][-1], 1), '| Réel :', val_reel)
    lst_local.pop()

## Erreurs
sum_MSE, sum_MAE = 0, 0
for k in range(N_test):
    sum_MSE += (val_pred - val_reel) ** 2
    sum_MAE += np.abs(val_pred - val_reel)
RMSE = np.sqrt(sum_MSE / N_test)
MAE = sum_MAE / N_test
print("K-NN")
print("RMSE :", RMSE, "m")
print("MAE :", MAE, "m")